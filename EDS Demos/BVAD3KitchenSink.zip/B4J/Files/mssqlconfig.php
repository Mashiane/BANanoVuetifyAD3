<?php
const DB_HOST = '(local)\sqlexpress';
const DB_NAME = 'test';
const DB_USER = 'root';
const DB_PASS = '';
?>