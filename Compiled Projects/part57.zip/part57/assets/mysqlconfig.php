<?php
const DB_HOST = '165.73.80.252';
const DB_NAME = 'agritrax';
const DB_USER = 'anele';
const DB_PASS = 'usioloeso';
?>