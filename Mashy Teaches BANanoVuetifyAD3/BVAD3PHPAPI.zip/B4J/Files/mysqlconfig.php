<?php
const DB_HOST = 'localhost';
const DB_NAME = 'wardlog';
const DB_USER = 'root';
const DB_PASS = '';
?>