<?php
const DB_HOST = '(local)\sqlexpress';
const DB_NAME = 'estore';
const DB_USER = 'sa';
const DB_PASS = 'usioloeso123';
?>