<?php
const DB_HOST = '127.0.0.1';
const DB_NAME = 'estore';
const DB_USER = 'postgres';
const DB_PASS = 'usioloeso123';
const DB_PORT = '5432';
?>