// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBEBmYLOWM4qXZ-xmIe3gp-we1V1PbFyHo",
  authDomain: "bvad3-bfa49.firebaseapp.com",
  databaseURL: "https://bvad3-bfa49-default-rtdb.firebaseio.com",
  projectId: "bvad3-bfa49",
  storageBucket: "bvad3-bfa49.appspot.com",
  messagingSenderId: "761408936764",
  appId: "1:761408936764:web:c8421243ef2403ebf71c39",
  measurementId: "G-W3KYQ2ZV1F"
};