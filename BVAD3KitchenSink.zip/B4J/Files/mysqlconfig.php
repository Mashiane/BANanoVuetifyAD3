<?php
const DB_HOST = 'localhost';
const DB_NAME = 'bvad3products';
const DB_USER = 'root';
const DB_PASS = '';
const DB_KEY = 'mashy';
?>