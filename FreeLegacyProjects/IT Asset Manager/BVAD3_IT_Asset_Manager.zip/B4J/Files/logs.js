listData = [{
        'id': 1,
        'Employee': 'John Doe',
        'ImgSrc': 'assets/Avatar_Male.svg',
        'TimeStamp': '05/25/2018',
        'Message': 'A new hardware Lenovo Yoga has been added'
    },
    {
        'id': 2,
        'Employee': 'Mary Saveley',
        'ImgSrc': 'assets/Avatar_Female.svg',
        'TimeStamp': '05/25/2018',
        'Message': 'A new hardware Lenovo Yoga has been added'
    },
    {
        'id': 3,
        'Employee': 'Yang Wang',
        'ImgSrc': 'assets/Avatar_Male.svg',
        'TimeStamp': '05/28/2018',
        'Message': 'A new software Visual Studio 2017 has been added'
    },
    {
        'id': 4,
        'Employee': 'Mario Pontes',
        'ImgSrc': 'assets/Avatar_Female.svg',
        'TimeStamp': '05/28/2018',
        'Message': 'The software SQL Server 2017 has been requested'
    },
    {
        'id': 5,
        'Employee': 'Karin Josephs',
        'ImgSrc': 'assets/Avatar_Female.svg',
        'TimeStamp': '06/08/2018',
        'Message': 'A new hardware Brother DCP-9020CDW has been added'
    },
    {
        'id': 6,
        'Employee': 'Paul Henriot',
        'ImgSrc': 'assets/Avatar_Male.svg',
        'TimeStamp': '06/12/2018',
        'Message': 'A new License for software Visual Studio 2017 has been issued'
    },
    {
        'id': 7,
        'Employee': 'David Anto',
        'ImgSrc': 'assets/Avatar_Male.svg',
        'TimeStamp': '06/14/2018',
        'Message': 'The software Adobe Illustrator has been requested'
    }
]