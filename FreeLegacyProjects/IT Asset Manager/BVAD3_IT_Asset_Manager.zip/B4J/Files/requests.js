requestData = [{
        'TaskID': 1,
        'Employee': 'Mary Saveley',
        'RequestType': 'Hardware',
        'RequestedItem': 'Canon PIXMA TS9150',
        'RequestedOn': new Date('05/22/2018'),
        'Priority': 'Normal',
        'Status': 'Pending',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 2,
        'Employee': 'Paul Henriot',
        'RequestType': 'Hardware',
        'RequestedItem': 'Lenovo Yoga',
        'RequestedOn': new Date('03/10/2017'),
        'Priority': 'Normal',
        'Status': 'Approved',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 3,
        'Employee': 'Pascale Cartrain',
        'RequestType': 'Software',
        'RequestedItem': 'Visual Studio 2017',
        'RequestedOn': new Date('02/12/2018'),
        'Priority': 'Normal',
        'Status': 'Approved',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 4,
        'Employee': 'David Anto',
        'RequestType': 'Hardware',
        'RequestedItem': 'Acer Aspire',
        'RequestedOn': new Date('06/10/2017'),
        'Priority': 'Normal',
        'Status': 'Rejected',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 5,
        'Employee': 'Yang Wang',
        'RequestType': 'Software',
        'RequestedItem': 'Adobe Illustrator',
        'RequestedOn': new Date('05/15/2018'),
        'Priority': 'Normal',
        'Status': 'Pending',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 6,
        'Employee': 'John Doe',
        'RequestType': 'Hardware',
        'RequestedItem': 'Lenovo Yoga',
        'RequestedOn': new Date('04/10/2018'),
        'Priority': 'Normal',
        'Status': 'Rejected',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 7,
        'Employee': 'David Anto',
        'RequestType': 'Software',
        'RequestedItem': 'SQL Server 2017',
        'RequestedOn': new Date('05/25/2018'),
        'Priority': 'Normal',
        'Status': 'Approved',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 8,
        'Employee': 'Mario Pontes',
        'RequestType': 'Hardware',
        'RequestedItem': 'Dell Inspiron',
        'RequestedOn': new Date('05/20/2018'),
        'Priority': 'Normal',
        'Status': 'Approved',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 9,
        'Employee': 'Pascale Cartrain',
        'RequestType': 'Hardware',
        'RequestedItem': 'Acer Aspire',
        'RequestedOn': new Date('04/10/2018'),
        'Priority': 'Normal',
        'Status': 'Pending',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 10,
        'Employee': 'Karin Josephs',
        'RequestType': 'Hardware',
        'RequestedItem': 'Lenovo Yoga',
        'RequestedOn': new Date('02/12/2018'),
        'Priority': 'Normal',
        'Status': 'Pending',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 11,
        'Employee': 'Karin Josephs',
        'RequestType': 'Software',
        'RequestedItem': 'SQL Server 2017',
        'RequestedOn': new Date('06/10/2017'),
        'Priority': 'Normal',
        'Status': 'Pending',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 12,
        'Employee': 'Mary Saveley',
        'RequestType': 'Hardware',
        'RequestedItem': 'Acer Aspire',
        'RequestedOn': new Date('03/10/2017'),
        'Priority': 'Normal',
        'Status': 'Pending',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 13,
        'Employee': 'Paul Henriot',
        'RequestType': 'Software',
        'RequestedItem': 'Blender',
        'RequestedOn': new Date('05/25/2018'),
        'Priority': 'Normal',
        'Status': 'Approved',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 14,
        'Employee': 'Pascale Cartrain',
        'RequestType': 'Software',
        'RequestedItem': 'Visual Studio 2017',
        'RequestedOn': new Date('05/25/2018'),
        'Priority': 'Normal',
        'Status': 'Rejected',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 15,
        'Employee': 'Yang Wang',
        'RequestType': 'Hardware',
        'RequestedItem': 'Lenovo Yoga',
        'RequestedOn': new Date('05/25/2018'),
        'Priority': 'Normal',
        'Status': 'Pending',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 16,
        'Employee': 'John Doe',
        'RequestType': 'Hardware',
        'RequestedItem': 'Lenovo Yoga',
        'RequestedOn': new Date('05/25/2018'),
        'Priority': 'Normal',
        'Status': 'Approved',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 17,
        'Employee': 'David Anto',
        'RequestType': 'Software',
        'RequestedItem': 'SQL Server 2017',
        'RequestedOn': new Date('05/25/2018'),
        'Priority': 'Normal',
        'Status': 'Pending',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 18,
        'Employee': 'Mario Pontes',
        'RequestType': 'Software',
        'RequestedItem': 'COREL Draw 2017',
        'RequestedOn': new Date('06/10/2017'),
        'Priority': 'Normal',
        'Status': 'Approved',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 19,
        'Employee': 'Pascale Cartrain',
        'RequestType': 'Hardware',
        'RequestedItem': 'Dell Inspiron',
        'RequestedOn': new Date('03/10/2017'),
        'Priority': 'Normal',
        'Status': 'Rejected',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 20,
        'Employee': 'David Anto',
        'RequestType': 'Hardware',
        'RequestedItem': 'Lenovo Yoga',
        'RequestedOn': new Date('05/25/2018'),
        'Priority': 'Normal',
        'Status': 'Approved',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 21,
        'Employee': 'Karin Josephs',
        'RequestType': 'Hardware',
        'RequestedItem': 'Acer Aspire',
        'RequestedOn': new Date('05/25/2018'),
        'Priority': 'Normal',
        'Status': 'Rejected',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 22,
        'Employee': 'John Doe',
        'RequestType': 'Software',
        'RequestedItem': 'FileZilla',
        'RequestedOn': new Date('06/10/2017'),
        'Priority': 'Normal',
        'Status': 'Pending',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 23,
        'Employee': 'David Anto',
        'RequestType': 'Software',
        'RequestedItem': 'Blender',
        'RequestedOn': new Date('02/12/2018'),
        'Priority': 'Normal',
        'Status': 'Approved',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 24,
        'Employee': 'Mario Pontes',
        'RequestType': 'Software',
        'RequestedItem': 'CCleaner',
        'RequestedOn': new Date('03/10/2017'),
        'Priority': 'Normal',
        'Status': 'Approved',
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 25,
        'Employee': 'Pascale Cartrain',
        'RequestType': 'Hardware',
        'RequestedItem': 'Lenovo Yoga',
        'RequestedOn': new Date('06/10/2017'),
        'Priority': 'Normal',
        'Status': 'Pending',
        'Note': 'Remarks are noted'
    }
]