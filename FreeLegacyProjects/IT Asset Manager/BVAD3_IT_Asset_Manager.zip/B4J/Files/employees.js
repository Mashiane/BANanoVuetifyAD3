employeeData = [{
        'id': 1,
        'Employee': 'John Doe',
        'ImgSrc': 'assets/Avatar_Male.svg',
        'Email': 'john.doe@sample.com'
    },
    {
        'id': 2,
        'Employee': 'Paul Henriot',
        'ImgSrc': 'assets/Avatar_Male.svg',
        'Email': 'paul.henriot@sample.com'
    },
    {
        'id': 3,
        'Employee': 'David Anto',
        'ImgSrc': 'assets/Avatar_Male.svg',
        'Email': 'david.anto@sample.com'
    },
    {
        'id': 4,
        'Employee': 'Mary Saveley',
        'ImgSrc': 'assets/Avatar_Female.svg',
        'Email': 'mary.saveley@sample.com'
    },
    {
        'id': 5,
        'Employee': 'Mario Pontes',
        'ImgSrc': 'assets/Avatar_Female.svg',
        'Email': 'mario.pontes@sample.com'
    },
    {
        'id': 6,
        'Employee': 'Pascale Cartrain',
        'ImgSrc': 'assets/Avatar_Male.svg',
        'Email': 'pascale.cartrain@sample.com'
    },
    {
        'id': 7,
        'Employee': 'Karin Josephs',
        'ImgSrc': 'assets/Avatar_Female.svg',
        'Email': 'karin.josephs@sample.com'
    },
    {
        'id': 8,
        'Employee': 'Yang Wang',
        'ImgSrc': 'assets/Avatar_Female.svg',
        'Email': 'yang.wang@sample.com'
    }
]