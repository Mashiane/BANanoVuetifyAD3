licenseData = [{
        'TaskID': 1,
        'Employee': 'Paul Henriot',
        'Email': 'paul.henriot@sample.com',
        'Software': 'Visual Studio 2017',
        'LicenseKey': 'LDGTE379892-28092KJ-903P',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 2,
        'Employee': 'Karin Josephs',
        'Email': 'karin.josephs@sample.com',
        'Software': 'Blender',
        'LicenseKey': '',
        'IssuedOn': new Date('02/12/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 3,
        'Employee': 'Mary Saveley',
        'Email': 'mary.saveley@sample.com',
        'Software': 'Visual Studio Code',
        'LicenseKey': '',
        'IssuedOn': new Date('12/22/2017'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 4,
        'Employee': 'David Anto',
        'Email': 'david.anto@sample.com',
        'Software': 'Visual Studio 2017',
        'LicenseKey': 'LDGTE356725-28787TH-876L',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 5,
        'Employee': 'Yang Wang',
        'Email': 'yang.wang@sample.com',
        'Software': 'Visual Studio 2017',
        'LicenseKey': 'LDGFJ765243-36748YI-967N',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 6,
        'Employee': 'Paul Henriot',
        'Email': 'paul.henriot@sample.com',
        'Software': 'FileZilla',
        'LicenseKey': '',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 7,
        'Employee': 'Mary Saveley',
        'Email': 'mary.saveley@sample.com',
        'Software': 'Blender',
        'LicenseKey': '',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 8,
        'Employee': 'John Doe',
        'Email': 'john.doe@sample.com',
        'Software': 'Visual Studio 2017',
        'LicenseKey': 'LDGTE379890-28078IJ-904K',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 9,
        'Employee': 'Karin Josephs',
        'Email': 'karin.josephs@sample.com',
        'Software': 'Visual Studio 2017',
        'LicenseKey': 'LDGTE379892-28089TJ-987M',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 10,
        'Employee': 'Yang Wang',
        'Email': 'yang.wang@sample.com',
        'Software': 'FileZilla',
        'LicenseKey': '',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 11,
        'Employee': 'Paul Henriot',
        'Email': 'paul.henriot@sample.com',
        'Software': 'Visual Studio 2017',
        'LicenseKey': 'LDGTE379790-28023KF-267H',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 12,
        'Employee': 'David Anto',
        'Email': 'david.anto@sample.com',
        'Software': 'Blender',
        'LicenseKey': '',
        'IssuedOn': new Date('02/12/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 13,
        'Employee': 'Mary Saveley',
        'Email': 'mary.saveley@sample.com',
        'Software': 'Visual Studio Code',
        'LicenseKey': '',
        'IssuedOn': new Date('12/22/2017'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 14,
        'Employee': 'Karin Josephs',
        'Email': 'karin.josephs@sample.com',
        'Software': 'Visual Studio 2017',
        'LicenseKey': 'GRDFJ789833-28092KJ-942I',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 15,
        'Employee': 'John Doe',
        'Email': 'john.doe@sample.com',
        'Software': 'Visual Studio 2017',
        'LicenseKey': 'RDGSJ379892-28092KJ-3444K',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 16,
        'Employee': 'Paul Henriot',
        'Email': 'paul.henriot@sample.com',
        'Software': 'FileZilla',
        'LicenseKey': '',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 17,
        'Employee': 'Mary Saveley',
        'Email': 'mary.saveley@sample.com',
        'Software': 'Blender',
        'LicenseKey': '',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 18,
        'Employee': 'Yang Wang',
        'Email': 'yang.wang@sample.com',
        'Software': 'Visual Studio 2017',
        'LicenseKey': 'LDHJK379892-28092KJ-956K',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 19,
        'Employee': 'Karin Josephs',
        'Email': 'karin.josephs@sample.com',
        'Software': 'Visual Studio 2017',
        'LicenseKey': 'LDHTK367290-28092KJ-906J',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 20,
        'Employee': 'Yang Wang',
        'Email': 'yang.wang@sample.com',
        'Software': 'FileZilla',
        'LicenseKey': '',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 21,
        'Employee': 'Paul Henriot',
        'Email': 'paul.henriot@sample.com',
        'Software': 'Visual Studio 2017',
        'LicenseKey': 'LDGTE379892-28078GR-978G',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 22,
        'Employee': 'Karin Josephs',
        'Email': 'karin.josephs@sample.com',
        'Software': 'Blender',
        'LicenseKey': '',
        'IssuedOn': new Date('02/12/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 23,
        'Employee': 'Mary Saveley',
        'Email': 'mary.saveley@sample.com',
        'Software': 'Visual Studio Code',
        'LicenseKey': '',
        'IssuedOn': new Date('12/22/2017'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 24,
        'Employee': 'David Anto',
        'Email': 'david.anto@sample.com',
        'Software': 'Visual Studio 2017',
        'LicenseKey': 'LDGTE379834-28092YJ-989D',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 25,
        'Employee': 'Yang Wang',
        'Email': 'yang.wang@sample.com',
        'Software': 'Visual Studio 2017',
        'LicenseKey': 'LDGTE379834-28092JI-905O',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 26,
        'Employee': 'Paul Henriot',
        'Email': 'paul.henriot@sample.com',
        'Software': 'FileZilla',
        'LicenseKey': '',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 27,
        'Employee': 'Mary Saveley',
        'Email': 'mary.saveley@sample.com',
        'Software': 'Blender',
        'LicenseKey': '',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 28,
        'Employee': 'John Doe',
        'Email': 'john.doe@sample.com',
        'Software': 'Visual Studio 2017',
        'LicenseKey': 'LDGTE379893-28092KR-967L',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 29,
        'Employee': 'Karin Josephs',
        'Email': 'karin.josephs@sample.com',
        'Software': 'Visual Studio 2017',
        'LicenseKey': 'TYJHE379777-28092PP-908T',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    },
    {
        'TaskID': 30,
        'Employee': 'Yang Wang',
        'Email': 'yang.wang@sample.com',
        'Software': 'FileZilla',
        'LicenseKey': '',
        'IssuedOn': new Date('05/25/2018'),
        'Note': 'Remarks are noted'
    }
]