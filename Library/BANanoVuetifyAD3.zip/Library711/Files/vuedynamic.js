(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('vue')) :
    typeof define === 'function' && define.amd ? define(['exports', 'vue'], factory) :
    (global = global || self, factory(global.VueDynamic = {}, global.Vue));
}(this, (function (exports, Vue) { 'use strict';

    Vue = Vue && Vue.hasOwnProperty('default') ? Vue['default'] : Vue;

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    var toString = Object.prototype.toString;
    var isFunction = function (arg) { return typeof arg === 'function'; };
    var isObject = function (arg) {
        return toString.call(arg) === '[object Object]';
    };
    var warn = Vue.util.warn;

    var objCompsToArr = function (objComponents) {
        var components = [];
        for (var _i = 0, _a = Object.entries(objComponents); _i < _a.length; _i++) {
            var _b = _a[_i], key = _b[0], value = _b[1];
            if (isObject(value)) {
                components.push(Object.assign(value, { name: key }));
            }
        }
        return components;
    };
    var invalidMsg = function (msg) { return warn("invalid " + msg + " will be ignored!"); };
    var nonMsg = function (msg) { return warn("no " + msg + " found thus it will be ignored!"); };
    var generateField = function (comp, component, type) {
        var field = comp[type];
        if (isObject(field)) {
            var wrappedField = {};
            for (var _i = 0, _a = Object.entries(field || {}); _i < _a.length; _i++) {
                var _b = _a[_i], fieldName = _b[0], method = _b[1];
                // prettier-ignore
                wrappedField[fieldName] = isFunction(method)
                    ? method
                    // @ts-ignore
                    : Function[Array.isArray(method) ? 'apply' : 'call'](null, method);
            }
            component[type] = wrappedField;
        }
        else if (field) {
            return invalidMsg(type);
        }
        return true;
    };
    var buildComponent = function (comps, notFirst) {
        if (notFirst === void 0) { notFirst = false; }
        if (!comps) {
            return;
        }
        if (isObject(comps)) {
            comps = objCompsToArr(comps);
        }
        else if (!Array.isArray(comps)) {
            return invalidMsg('components');
        }
        if (comps.length === 0) {
            return nonMsg('components');
        }
        var wrapTemp = '';
        var wrapComp = {};
        var count = 0;
        comps.forEach(function (comp, index) {
            var _a = comp.name, name = _a === void 0 ? "Dynamic__" + index : _a, template = comp.template, data = comp.data, components = comp.components;
            if (!template) {
                return nonMsg('template');
            }
            wrapTemp += "<" + name + (notFirst ? '' : ' v-on="$parent.$listeners"') + " />";
            var component = (wrapComp[name] = { template: template });
            if (!generateField(comp, component, 'filters') ||
                !generateField(comp, component, 'methods')) {
                return;
            }
            if (data) {
                component.data = isFunction(data) ? data : function () { return (__assign({}, data)); };
            }
            if (components) {
                component.components = buildComponent(components, true);
            }
            count++;
        });
        if (!count) {
            return;
        }
        return notFirst
            ? wrapComp
            : {
                name: 'Dynamic__Root',
                template: count === 1 ? wrapTemp : "<div>" + wrapTemp + "</div>",
                components: wrapComp,
            };
    };
    var Dynamic = {
        name: 'vue-dynamic',
        template: "<component :is=\"view\" />",
        props: {
            comps: {
                validator: function (value) {
                    return !value || Array.isArray(value) || isObject(value);
                },
            },
            emptyView: {
                required: true,
                validator: function (value) { return isObject(value); },
            },
        },
        data: function () {
            return {
                view: this.emptyView,
            };
        },
        // @ts-ignore
        watch: {
            comps: {
                immediate: true,
                // @ts-ignore
                handler: 'build',
            },
        },
        methods: {
            build: function () {
                this.view = buildComponent(this.comps) || this.emptyView;
            },
        },
    };

    var VueDynamic = function (Vue, options) { var _a; return Vue.component(((_a = options) === null || _a === void 0 ? void 0 : _a.name) || 'Dynamic', Dynamic); };
    if (typeof window !== 'undefined' && window.Vue) {
        // @ts-ignore
        window.Vue.use(VueDynamic);
    }
    var install = VueDynamic;

    exports.Dynamic = Dynamic;
    exports.VueDynamic = VueDynamic;
    exports.default = VueDynamic;
    exports.install = install;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
